import logo from './logo.svg'
import './App.css'
import Index from './components/Dashboard/index'

function App () {
  return <Index />
}

export default App
